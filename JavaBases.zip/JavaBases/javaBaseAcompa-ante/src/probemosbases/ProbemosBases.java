package probemosbases;
import java.sql.*;
public class ProbemosBases {
    public static void main(String[] args) {
        Class.forName("").newInstance();
    }
}