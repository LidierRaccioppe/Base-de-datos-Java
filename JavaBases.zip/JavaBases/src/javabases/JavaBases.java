package javabases;
public class JavaBases {
    public static void main(String[] args) {
        MiVentana rellena = new MiVentana();
        rellena.setVisible(true);
    }
}