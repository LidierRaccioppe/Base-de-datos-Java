package javabases;

import static java.lang.Integer.parseInt;
import javax.swing.JTextField;
import java.sql.CallableStatement;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import java.sql.*;

public class Civil {
    private int ci;
    private String nombresCiviles;
    private String apellidosCiviles;

    public int getCi() {
        return ci;
    }

    public void setCi(int ci) {
        this.ci = ci;
    }

    public String getNombresCiviles() {
        return nombresCiviles;
    }

    public void setNombresCiviles(String nombresCiviles) {
        this.nombresCiviles = nombresCiviles;
    }

    public String getApellidosCiviles() {
        return apellidosCiviles;
    }

    public void setApellidosCiviles(String apellidosCiviles) {
        this.apellidosCiviles = apellidosCiviles;
    }
    
    //este metodo inserta valores de los campos de texto en la base de datos 
    public void insertarCivil(JTextField CIObt,JTextField nombresObt,JTextField apellidosObt){
        setCi(parseInt(CIObt.getText()));
        setNombresCiviles(nombresObt.getText());
        setApellidosCiviles(apellidosObt.getText());
        //esto sera usado para despues
        String consulta = "insert into Civiles (CI, nombres, apellidos) values (?,?,?);";
        Conection conect = new Conection();
        
        try {
            /* 
            prepara un comando usando el string que les demos, pero antes debe de conectarse al base,
            tambien debemos poner los argumentos
            */
            CallableStatement cs = conect.conectandose().prepareCall(consulta);
            /*esto es para que en los interogantes que dejamos antes estos 
            sean llenados en el orden de los numero que pondremos ahora*/
            cs.setString (1, Integer.toString(getCi()));
            cs.setString (2, getNombresCiviles());
            cs.setString (3, getApellidosCiviles());
            // Ejecutara todas la linea preparadas disponibles en orden
            cs.execute();
            // para la retroalimentacion
            JOptionPane.showMessageDialog(null, "La Insercion fue exitosa");
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Hubo un error en la insercion"+e.getMessage());
        }
    }
    
    // esto mostrara los cambios que sufra la tabla dentro de la base de datos y los mostrara
    // en la tabla de la aplicacion

    public void mostrarCiviles (JTable datosTablaCivil){
        Conection objConexion = new Conection();
        /*
        Este nos permite usar metodos que manejen el uso de tablas, del
        estilo de JTable sin tener que implementar TableModel, que 
        es una interface.
        */
        DefaultTableModel modeloTabla = new DefaultTableModel();
        /*
        TableRowSorter, permite el ordenar y filtrar tablas del estilo
        de JTable (aca usaremos las de DefaultTableModel).
        */
        TableRowSorter<TableModel> ordenarTabla = new TableRowSorter<TableModel> (modeloTabla);
        datosTablaCivil.setRowSorter(ordenarTabla);
        //la consulta
        String sql="select * from Civil;";
        // cada una agrega una columna extra a la visualizacion con el nombre que elijamos
        modeloTabla.addColumn("id");
        modeloTabla.addColumn("nombres");
        modeloTabla.addColumn("apellidos");
        // Esto actualiza la tabla con los nuevos cambios que sufrio
        // desde su ultima setModel o iniciacion
        datosTablaCivil.setModel(modeloTabla);
        
        /*
        Esto sera usado para obtener los datos de la base de datos por
        linea
        */
        String [] datos = new String [3];
        //Esto se usara para executar la consulta (aca lo llamamos sql);
        Statement st;
        try{
            st = objConexion.conectandose().createStatement();
            // el ResultSet sera para guardar los resultados de la consulta
            ResultSet resultado = st.executeQuery(sql);
             /*
            Esto sera lo que tome lo obtenido de la consulta y 
            lo ingrese en el visual 
            */
            while (resultado.next()){
                datos[0]=resultado.getString(1);
                datos[1]=resultado.getString(2);
                datos[2]=resultado.getString(3);
                // esto añade los datos en las lineas
                modeloTabla.addRow(datos);
            }
            //esto actuliza la apariencia de la tabla
            datosTablaCivil.setModel(modeloTabla);
            }catch (Exception ex){
                JOptionPane.showMessageDialog(null, "Error en la lectura de datos"+ex.toString());
            }
    }
    //recordar: modificarlo para ser mas general en el futuro
    //metodo suplmementario para el otros metodos
    public void seleccionarCivil(JTable datosTablaCivil, JTextField datosCI,JTextField datosNombres,JTextField datosApellidos){
        //este metodo es para que cuando alguien seleccione una fila en la tabla, este le de los valores
        try{
            //getSelectRow es para ver el indice de la linea
            int fila = datosTablaCivil.getSelectedRow();
            // es para ver si se selecciono algo
            if (fila >= 0 ){
                /*
                Esto tomara los datos de la tabla y sus campos y se los dara a los
                textFields que corresponda, esto facilitara por si se tiene que 
                hacer modificaciones pequeñas o solo cambiar un campo
                */
                datosCI.setText(datosTablaCivil.getValueAt(fila, 0).toString());
                datosNombres.setText(datosTablaCivil.getValueAt(fila, 1).toString());
                datosApellidos.setText(datosTablaCivil.getValueAt(fila, 2).toString());
                // aca no pongo ningun feedback por que se ve si se llenan los textFields
            }
            else{
                //por si no han seleccionado la linea
                JOptionPane.showMessageDialog(null, "Fila no se selecciono");
            }
        }catch (Exception ex){
            JOptionPane.showMessageDialog(null, "Error en la seleccion"+ex.toString());
        }
    }
    
    // esto permite alterar los valores de una fila dentro de la tabla sin tener que eliminarla y volverla a insertar
    public void modificarCivil(JTextField datosCI, JTextField datosNombres, JTextField datosApellidos){
        
        //obtengo y guardo los datos
        setCi(Integer.parseInt(datosCI.getText()));
        setNombresCiviles(datosCI.getText());
        setApellidosCiviles(datosCI.getText());
        // establesco conexion
        Conection objCon = new Conection();
        // la consulta que actualizara los campos nombres y apellidos donde la id
        // sea igual a la id ingresada
        String consulta = "update Civil set civil.nombres = ?, civil.apellidos = ? where civil.id = ?";
        
        try {
            /* 
            prepara un comando usando el string que les demos, pero antes debe de conectarse al base,
            tambien debemos poner los argumentos
            */
            CallableStatement cs = objCon.conectandose().prepareCall(consulta);
            /*esto es para que en los interogantes que dejamos antes estos 
            sean llenados en el orden de los numero que pondremos ahora*/
            cs.setInt(1, getCi());
            cs.setString(2, getNombresCiviles());
            cs.setString(3, getApellidosCiviles());
            // Ejecutara todas la linea preparadas disponibles en orden
            cs.execute();
            // para la retroalimentacion
            JOptionPane.showMessageDialog(null, "Modificado correctamente");
        }catch (Exception ex){
            JOptionPane.showMessageDialog(null, "Error en la modificacion"+ex.toString());
        }
    }
    // esto permitirá eliminar a un civil del registro
    public void eliminarCiviles(JTextField dataCI){
        //obtengo y guardo los datos
        setCi(Integer.parseInt(dataCI.getText()));
        // cargo la conexion
        Conection objCon = new Conection();
        // consulta en sql que borrara la linea que contenga
        // la ci indicada
        String consulta = "delete from Civil where alumnos.ci = ? ;";
        
        try{
            /* 
            prepara un comando usando el string que les demos, pero antes debe de conectarse al base,
            tambien debemos poner los argumentos
            */
            CallableStatement cs = objCon.conectandose().prepareCall(consulta);
            /*esto es para que en los interogantes que dejamos antes estos 
            sean llenados en el orden de los numero que pondremos ahora*/
            cs.setInt(1, getCi());
            // Ejecutara todas la linea preparadas disponibles en orden
            cs.execute();
            // para la retroalimentacion
            JOptionPane.showMessageDialog(null, "Eliminado correctamente");
        }catch (Exception ex){
            JOptionPane.showMessageDialog(null, "Error al eliminar"+ex.toString());
        }
    }
}
