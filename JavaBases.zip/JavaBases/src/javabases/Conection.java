package javabases;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class Conection {

    Connection con = null;

    //ip o direccion del servidor
    static final String URL = "localhost";
    // nombre del usuario con el que entrar a la base
    static final String USER = "root";
    // contraseña con la que entrar a la base
    static final String CLAVE = "root";
    // el nombre de la base de datos a la que vamos a entrar 
    static final String BASE = "Civil";
    // El puerto en el que esta alojada la base
    static final String PUERTO = "3306";

    // necesaria para establacer la conexion
    String cadena = "jdbc:mysql://" + URL + ":" + PUERTO + "/" + BASE;

    public Connection conectandose() {

        try {
            // Con es lo siguiente inicialisamos dinamicamente un objeto de la clase de dentro
            Class.forName("com.mysql.cj.jdbc.Driver");

            //con esto cargamos el driver
            con = DriverManager.getConnection(cadena, USER, CLAVE);
            //  Statement stmt = con.createStatement();
            /* 
            Con la declaracion siguiente le decimos que cree una 
            base de datos con el nombre Civil
            */
            // stmt.execute("create database Civil");
            // Para tener una retroalimentacion de que salio bien
            JOptionPane.showMessageDialog(null,"Base de datos creada correctamente");
        } catch (Exception e){
            JOptionPane.showMessageDialog(null,"Error en la conexion a la base de datos" + e.toString());
        } finally {
            try {
                // Cerramos posibles conexiones abiertas
                if (con != null) {
                    con.close();
                }
            } catch (Exception e) {
                System.out.println("Error cerrando conexiones: "
                        + e.toString());
            }
        }

        return con;
    }

}
